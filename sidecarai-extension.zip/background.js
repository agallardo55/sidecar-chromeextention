// Background script for SidecarAI Bid Scanner Chrome Extension

// Handle extension installation
chrome.runtime.onInstalled.addListener((details) => {
  console.log('SidecarAI Bid Scanner extension installed:', details.reason);
  
  // Initialize default settings
  if (details.reason === 'install') {
    chrome.storage.local.set({
      isAuthenticated: false,
      userPreferences: {
        autoScan: false,
        notifications: true
      }
    });
  }
});

// Handle messages from content scripts and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background script received message:', request);
  
  switch (request.type) {
    case 'GET_AUTH_STATUS':
      chrome.storage.local.get(['isAuthenticated'], (result) => {
        sendResponse({ isAuthenticated: result.isAuthenticated || false });
      });
      return true; // Keep message channel open for async response
      
    case 'SET_AUTH_STATUS':
      chrome.storage.local.set({ isAuthenticated: request.isAuthenticated });
      sendResponse({ success: true });
      break;
      
    case 'OPEN_SIDE_PANEL':
      chrome.sidePanel.open({ windowId: sender.tab?.windowId });
      sendResponse({ success: true });
      break;
      
    default:
      sendResponse({ error: 'Unknown message type' });
  }
});

// Handle tab updates to inject content scripts when needed
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    // Check if this is a supported website for bid scanning
    const supportedSites = [
      'copart.com',
      'iaai.com',
      'manheim.com',
      'adesa.com'
    ];
    
    const isSupportedSite = supportedSites.some(site => tab.url.includes(site));
    
    if (isSupportedSite) {
      // Inject content script for supported sites
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['content-script.js']
      }).catch(err => console.log('Content script injection failed:', err));
    }
  }
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
  // Open the side panel when extension icon is clicked
  chrome.sidePanel.open({ windowId: tab.windowId });
}); 